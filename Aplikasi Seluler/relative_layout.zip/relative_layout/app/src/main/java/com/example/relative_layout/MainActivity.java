package com.example.relative_layout;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Mengaktifkan Edge to Edge jika diperlukan (opsional)
        // EdgeToEdge.enable(this);  // Hapus jika sudah diatur di AndroidManifest

        // Setup padding untuk tampilan
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.relativeLayout), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Setup onClick untuk tombol TampilNama
        findViewById(R.id.BtnTampil).setOnClickListener(v -> {
            EditText txtNama = findViewById(R.id.TxtNama);
            TextView label2 = findViewById(R.id.Label2);
            String nama = txtNama.getText().toString();

            if (!nama.isEmpty()) {
                label2.setText("Hello, " + nama);
            } else {
                label2.setText("");
                Toast.makeText(MainActivity.this, "Please enter your name", Toast.LENGTH_SHORT).show();
            }
        });
    }
}